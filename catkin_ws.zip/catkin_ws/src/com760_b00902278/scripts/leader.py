#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Twist, PoseStamped
from math import atan2, sqrt
import random

leader_pose = PoseStamped()
follower1_pose = PoseStamped()
follower2_pose = PoseStamped()

def leader_callback(data):
    global leader_pose
    leader_pose = data

def follower1_callback(data):
    global follower1_pose
    follower1_pose = data

def follower2_callback(data):
    global follower2_pose
    follower2_pose = data

def main():
    rospy.init_node('leader')
    leader_pub = rospy.Publisher('/turtle1/cmd_vel', Twist, queue_size=10)
    follower1_sub = rospy.Subscriber('/turtle2/pose', PoseStamped, follower1_callback)
    follower2_sub = rospy.Subscriber('/turtle3/pose', PoseStamped, follower2_callback)

    rate = rospy.Rate(10)
    while not rospy.is_shutdown():
        # Check if the followers are in the required formation position
        formation_distance = 2.0
        if sqrt((follower1_pose.pose.position.x - leader_pose.pose.position.x)**2 + (follower1_pose.pose.position.y - leader_pose.pose.position.y)**2) < formation_distance and sqrt((follower2_pose.pose.position.x - leader_pose.pose.position.x)**2 + (follower2_pose.pose.position.y - leader_pose.pose.position.y)**2) < formation_distance:
            # Turn to a random direction
            vel = Twist()
            vel.linear.x = 0.0
            vel.angular.z = random.uniform(-1.0, 1.0)
            leader_pub.publish(vel)

            # Keep moving in a straight line
            vel.linear.x = 1.0
            vel.angular.z = 0.0
            leader_pub.publish(vel)
        else:
            # Calculate the desired velocity based on the leader's trajectory
            vel = Twist()
            vel.linear.x = 1.0
            vel.angular.z = 0.5
            leader_pub.publish(vel)

        rate.sleep()

if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        pass
