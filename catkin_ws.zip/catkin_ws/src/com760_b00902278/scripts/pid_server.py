#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Twist, PoseStamped
from math import atan2, sqrt
import random
from turtlesim.srv import TeleportAbsolute
from my_custom_srv_msg_pkg.srv import MyCustomServiceMessage, MyCustomServiceMessageResponse

leader_pose = PoseStamped()
follower1_pose = PoseStamped()
follower2_pose = PoseStamped()

def leader_callback(data):
    global leader_pose
    leader_pose = data

def follower1_callback(data):
    global follower1_pose
    follower1_pose = data

def follower2_callback(data):
    global follower2_pose
    follower2_pose = data

def teleport_followers():
    # Teleport follower1 to its initial position
    rospy.wait_for_service('/turtle2/teleport_absolute')
    try:
        teleport = rospy.ServiceProxy('/turtle2/teleport_absolute', TeleportAbsolute)
        teleport(4.0, 2.0, 0.0)
    except rospy.ServiceException as e:
        print("Service call failed: %s"%e)

    # Teleport follower2 to its initial position
    rospy.wait_for_service('/turtle3/teleport_absolute')
    try:
        teleport = rospy.ServiceProxy('/turtle3/teleport_absolute', TeleportAbsolute)
        teleport(4.0, 8.0, 0.0)
    except rospy.ServiceException as e:
        print("Service call failed: %s"%e)

def move_to_center():
    rospy.wait_for_service('move_turtle_to_goal')
    try:
        move_turtle = rospy.ServiceProxy('move_turtle_to_goal', MyCustomServiceMessage)
        resp1 = move_turtle(5.544, 5.544)
        if resp1.success == True:
            print("Leader turtle moved to the center successfully")
        else:
            print("Failed to move the leader turtle to the center")
            # Teleport the leader turtle back to the center
            rospy.wait_for_service('/turtle1/teleport_absolute')
            try:
                teleport = rospy.ServiceProxy('/turtle1/teleport_absolute', TeleportAbsolute)
                teleport(5.544, 5.544, 0.0)
            except rospy.ServiceException as e:
                print("Service call failed: %s"%e)
    except rospy.ServiceException as e:
        print("Service call failed: %s"%e)

def main():
    rospy.init_node('leader')
    leader_pub = rospy.Publisher('/turtle1/cmd_vel', Twist, queue_size=10)
    follower1_sub = rospy.Subscriber('/turtle2/pose', PoseStamped, follower1_callback)
    follower2_sub = rospy.Subscriber('/turtle3/pose', PoseStamped, follower2_callback)

    rate = rospy.Rate(10)
    while not rospy.is_shutdown():
        # Check if the leader turtle approaches to the border
        border_distance = 0.5
        if leader_pose.pose.position.x < border_distance or leader_pose.pose.position.x > 10 - border_distance or leader_pose.pose.position.y < border_distance or leader_pose.pose.position.y > 10 -

